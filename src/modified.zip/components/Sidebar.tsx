"use client";

import React from 'react';
import { useProgress } from '@/context/ProgressContext';
import { useLab } from '@/context/LabContext';
import { useAuth } from '@/context/AuthContext';
import { LAB_DATA } from '@/data/labs';
import { 
  Shield, 
  X, 
  LayoutDashboard, 
  LogOut, 
  BookOpen, 
  Cpu, 
  Globe, 
  Lock, 
  CheckCircle2, 
  BookOpenCheck,
  Search,
  Terminal,
  ShieldAlert,
  Trophy,
  Sparkles
} from 'lucide-react';

export function Sidebar({ isMobileOpen, setIsMobileOpen, openDashboard, openLeaderboard, openDailyChallenge, onNavigate }: { 
  isMobileOpen: boolean, 
  setIsMobileOpen: (v: boolean) => void, 
  openDashboard: () => void,
  openLeaderboard: () => void,
  openDailyChallenge: () => void,
  onNavigate?: () => void
}) {
  const { data, isLabCompleted, isLabLocked, isTrackLocked, getRank } = useProgress();
  const { activeLabId, loadLab } = useLab();
  const { user, logout } = useAuth();

  const totalLabs = LAB_DATA.reduce((sum, track) => sum + track.labs.length, 0);
  const completedCount = data.completedLabs.length;
  
  // Calculate rank progress bar
  let fillPct = 0;
  const xp = data.xp;
  if (xp < 200) fillPct = (xp / 200) * 100;
  else if (xp < 500) fillPct = ((xp - 200) / 300) * 100;
  else if (xp < 1000) fillPct = ((xp - 500) / 500) * 100;
  else if (xp < 2000) fillPct = ((xp - 1000) / 1000) * 100;
  else if (xp < 3500) fillPct = ((xp - 2000) / 1500) * 100;
  else fillPct = 100;

  // Resolve track icons dynamically from labs data
  const renderTrackIcon = (iconName: string) => {
    const cls = "w-4 h-4 shrink-0";
    switch (iconName) {
      case 'BookOpen':    return <BookOpen className={cls} />;
      case 'Cpu':         return <Cpu className={cls} />;
      case 'Globe':       return <Globe className={cls} />;
      case 'Search':      return <Search className={cls} />;
      case 'Terminal':    return <Terminal className={cls} />;
      case 'ShieldAlert': return <ShieldAlert className={cls} />;
      default:            return <Shield className={cls} />;
    }
  };

  return (
    <>
      {/* Mobile overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black/70 z-40 md:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      <aside className={`
        fixed md:static inset-y-0 left-0 z-50
        w-full bg-[#171717]/95 border-r border-[#262626]
        transform transition-transform duration-200 ease-in-out
        flex flex-col h-screen font-sans
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        {/* Header Logo */}
        <div className="p-5 border-b border-[#262626] flex justify-between items-center bg-gradient-to-r from-zinc-950/60 to-zinc-900/30">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded border border-blue-600/50 bg-[#171717]/20 flex items-center justify-center">
              <Shield className="w-4 h-4 text-blue-500" />
            </div>
            <div>
              <h1 className="font-mono font-bold text-white tracking-wider text-xs leading-tight">PASSWORD<br/>CRACKING LAB</h1>
              <p className="text-[8px] text-cyan-600/80 tracking-[0.25em] uppercase font-mono">Security Auditor v1.0</p>
            </div>
          </div>
          <button className="md:hidden text-gray-400 hover:text-white" onClick={() => setIsMobileOpen(false)}>
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Rank / Rating Progress */}
        <div className="p-4 border-b border-[#262626]">
          <div className="flex justify-between text-[10px] text-gray-400 mb-1.5 uppercase tracking-widest font-mono">
            <span>Security Classification</span>
          </div>
          <div className="text-xs text-zinc-200 font-medium mb-2 font-mono">
            {getRank()}
          </div>
          <div className="h-1 w-full bg-black rounded-full overflow-hidden border border-[#262626]/80">
            <div 
              className="h-full bg-zinc-400 transition-all duration-500"
              style={{ width: `${Math.min(100, Math.max(0, fillPct))}%` }}
            />
          </div>
        </div>

        {/* Tracks List */}
        <div className="flex-1 overflow-y-auto py-3 space-y-3 custom-scrollbar">
          {LAB_DATA.map((track, trackIndex) => {
            const trackLocked = isTrackLocked(trackIndex);
            const trackCompleted = track.labs.every(l => isLabCompleted(l.id));
            const trackActive = !trackLocked && track.labs.some(l => activeLabId === l.id);

            return (
            <div key={track.id} className={`space-y-0.5 transition-opacity duration-300 ${trackLocked ? 'opacity-40' : ''}`}>
              <div
                className={`px-5 py-2 flex items-center gap-2 text-[10px] font-mono font-bold uppercase tracking-wider border-l-2
                  ${trackActive
                    ? 'border-cyan-600 bg-cyan-950/10 text-blue-500'
                    : trackLocked
                      ? 'border-transparent text-gray-400'
                      : 'border-transparent text-gray-400'}`}
                title={trackLocked ? `Complete "${LAB_DATA[trackIndex - 1]?.name}" to unlock this track` : ''}
              >
                {trackLocked
                  ? <Lock className="w-4 h-4 shrink-0 text-gray-400" />
                  : renderTrackIcon(track.icon)}
                <span className="flex-1 truncate">{track.name}</span>
                {trackCompleted && <CheckCircle2 className="w-3 h-3 text-blue-500" />}
                {trackLocked && <Lock className="w-3 h-3 text-gray-400" />}
              </div>

              <div className="flex flex-col">
                {track.labs.map((lab, index) => {
                  const isCompleted = isLabCompleted(lab.id);
                  const isLocked = trackLocked || isLabLocked(track.id, index);
                  const isActive = !isLocked && activeLabId === lab.id;

                  return (
                    <button
                      key={lab.id}
                      disabled={isLocked}
                      onClick={() => {
                        if (isLocked) return;
                        loadLab(track.id, lab.id);
                        if (onNavigate) onNavigate();
                        if (window.innerWidth < 768) setIsMobileOpen(false);
                      }}
                      title={trackLocked
                        ? `Complete "${LAB_DATA[trackIndex - 1]?.name}" first to unlock this track`
                        : isLocked
                          ? 'Complete the previous lab to unlock'
                          : ''}
                      className={`
                        w-full text-left px-5 py-2 flex items-center justify-between text-xs transition-all border-l-2 ml-2
                        ${isLocked ? 'cursor-not-allowed' : 'hover:bg-zinc-800/40 hover:border-zinc-600'}
                        ${isActive
                          ? 'bg-cyan-500/8 border-cyan-500 text-blue-400 font-medium shadow-[inset_0_0_12px_rgba(6,182,212,0.06)]'
                          : isCompleted
                            ? 'border-emerald-900/30 text-gray-400'
                            : isLocked
                              ? 'border-transparent text-gray-400'
                              : 'border-transparent text-gray-400 hover:text-zinc-200'}
                      `}
                      style={isActive ? { borderLeftWidth: '2px' } : {}}
                    >
                      <div className="flex items-center gap-2 truncate mr-2 flex-1 min-w-0">
                        <div className={`w-1 h-1 rounded-full shrink-0 ${
                          isCompleted ? 'bg-blue-600' : isActive ? 'bg-cyan-400 animate-pulse' : isLocked ? 'bg-zinc-700' : 'bg-zinc-600'
                        }`} />
                        <span className="truncate">{index + 1}. {lab.name}</span>
                      </div>

                      <div className="shrink-0 flex items-center justify-center">
                        {isCompleted ? (
                          <CheckCircle2 className="w-3 h-3 text-blue-500/70" />
                        ) : isLocked ? (
                          <Lock className="w-2.5 h-2.5 text-gray-400" />
                        ) : isActive ? (
                          <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_6px_rgba(6,182,212,0.5)]" />
                        ) : (
                          <div className="w-1 h-1 rounded-full bg-zinc-600" />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )})}
        </div>

        {/* User Card & Stats */}
        <div className="p-4 border-t border-[#262626] bg-black/20 space-y-4 font-mono text-[10px]">
          <div className="space-y-1.5 text-gray-400">
            <div className="flex justify-between items-center">
              <span>ACTIVE USER:</span>
              <span className="text-gray-300 max-w-[150px] truncate" title={user?.email || ''}>{user?.email}</span>
            </div>
            <div className="flex justify-between items-center">
              <span>TOTAL SCORE:</span>
              <span className="text-gray-300">{data.xp} XP</span>
            </div>
            <div className="flex justify-between items-center">
              <span>COMPLETED MODULES:</span>
              <span className="text-gray-300">{completedCount}/{totalLabs}</span>
            </div>
          </div>
          
          {user?.isAdmin || (useAuth().profile?.isAdmin) ? (
            <button 
              onClick={() => window.location.hash = '#/admin'}
              className="w-full flex items-center justify-center gap-2 py-2 bg-blue-500/10 border border-blue-400/30 text-blue-400 hover:text-amber-400 hover:bg-blue-500/20 rounded transition-colors text-[10px] uppercase font-mono tracking-widest font-bold mb-2"
            >
              <ShieldAlert className="w-3.5 h-3.5" /> Admin Control Panel
            </button>
          ) : null}

          <div className="grid grid-cols-4 gap-2">
            <button 
              onClick={openDashboard}
              title="Dashboard"
              className="col-span-1 flex items-center justify-center gap-1.5 py-2 bg-[#171717] border border-[#262626] text-gray-300 hover:text-white hover:bg-zinc-800/80 rounded transition-colors text-[10px] uppercase font-mono tracking-wider"
            >
              <LayoutDashboard className="w-3 h-3" /> Dash
            </button>
            <button 
              onClick={openDailyChallenge}
              title="Daily Challenge"
              className="col-span-1 flex items-center justify-center gap-1 py-2 bg-[#171717] border border-[#262626] text-blue-500 hover:text-blue-400 hover:border-cyan-900/50 hover:bg-[#171717]/20 rounded transition-colors text-[10px] uppercase font-mono tracking-wider"
            >
              <Sparkles className="w-3 h-3" /> Daily
            </button>
            <button 
              onClick={openLeaderboard}
              title="Leaderboard"
              className="col-span-1 flex items-center justify-center gap-1.5 py-2 bg-[#171717] border border-[#262626] text-blue-400 hover:text-amber-400 hover:border-amber-900/50 hover:bg-amber-950/20 rounded transition-colors text-[10px] uppercase font-mono tracking-wider"
            >
              <Trophy className="w-3 h-3" /> Rank
            </button>
            <button
              onClick={() => logout()}
              title="Sign Out"
              className="col-span-1 flex items-center justify-center py-2 bg-[#171717] border border-[#262626] text-gray-400 hover:text-red-400 hover:border-red-950/50 hover:bg-red-950/10 rounded transition-colors"
            >
              <LogOut className="w-3 h-3" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
